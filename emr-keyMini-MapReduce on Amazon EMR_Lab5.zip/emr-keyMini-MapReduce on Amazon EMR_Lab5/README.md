# Mini-MapReduce WordCount on Amazon EMR

## Description
This repository contains the mapper and reducer code for performing WordCount on Amazon EMR using Hadoop Streaming.

## Files
- mapper.py: Mapper script
- reducer.py: Reducer script
- corpus.txt: Input dataset (Wikipedia dump sample)
- README.md: This file

## HDFS Setup
Upload dataset to HDFS:
```bash
hdfs dfs -mkdir -p /user/hadoop/input
hdfs dfs -put corpus.txt /user/hadoop/input/

## Run WordCount MapReduce:
```bash
hdfs dfs -rm -r -f /user/hadoop/output/
hadoop jar /usr/lib/hadoop-mapreduce/hadoop-streaming.jar \
-files mapper.py,reducer.py \
-mapper mapper.py \
-reducer reducer.py \
-input /user/hadoop/input/ \
-output /user/hadoop/output/

## Output:
hdfs dfs -ls /user/hadoop/output/
hdfs dfs -head /user/hadoop/output/part-00000


---

### `corpus.txt` description
**File:** `corpus.txt`  
**Source:** Small Wikipedia dump  
**Size:** ~10 MB  
**Format:** Plain text, UTF-8  
**Sample:**
